@extends('adminlte::page')

@section('plugins.Datatables', true)

@section('title', 'Employee Master')

@section('content_header')
@stop

@section('content')
    <div class="container-fluid">
        <div class="col-md-12 mx-auto">
            <div class="container-fluid">
                <div class="col-md-6 mx-auto">
                    @include('layouts.alert')
                </div>
            </div>
            <div class="row">
                <div class="container-fluid">
                    <div class="card shadow">
                      <div class="card-header">
                        <div class="d-flex justify-content-between">
                          <h4 class="font-weight-bold text-dark py">EMPLOYEE MASTER</h4>
                          <div style="width:120px">
                            <button type="button" class="btn btn-block btn-primary" data-toggle="modal" data-target="#myModal1">Add</button>
                          </div>
                        </div>
                      </div>
            </div>
{{--employee Add--}}

            <div id="myModal1" class="modal fade" role="dialog">
                <div class="modal-dialog modal-xl">
            <div class="modal-content ">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title ">Add Employee</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body">
                    <div class="card-body ">
                        <form method="POST" class="form-row" action="{{ route('employeemaster.store') }}" enctype="multipart/form-data">
                            @csrf

                            {{-- <div class="form-group col-md-6">
                                <label for="employee_no" class="form-label fw-bold">Employee Number<a style="text-decoration: none;color:red">*</a></label>
                                <input type="number" name="employee_no" value="{{old("employee_no")}}" placeholder="Employee Number" class="form-control">
                            </div> --}}
                            {{-- <div class="form-group col-md-12">
                                <label for="fullname" class="form-label fw-bold">Employee Name</label>
                                <input type="text" name="fullname" value="{{old("fullname")}}" placeholder="Full Name" class="form-control">
                            </div> --}}
                            <div class="form-group col-md-6">
                                <label for="fullname" class="form-label fw-bold">First Name<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" name="firstname" value="{{old("firstname")}}" placeholder="First Name" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="fullname" class="form-label fw-bold">Last Name<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" name="lastname" value="{{old("lastname")}}" placeholder="Last Name" class="form-control">
                            </div>
                            <div class="form-group col-md-6 ">
                                <label for="fullname" class="form-label fw-bold">Middle Name</label>
                                <input type="text" name="middlename" value="{{old("middlename")}}" placeholder="Middle Name" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="form-label fw-bold" for="hire_date">Date of Joining<a style="text-decoration: none;color:red">*</a></label>
                                <input type="date" class="form-control" value="{{old("hire_date")}}"  placeholder="Date of Joining" name="hire_date" id="hire_date" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="form-label fw-bold" for="category">Category<a style="text-decoration: none;color:red">*</a></label>
                                <div class="form-label">
                                    <select id="category" name="category"  class="form-control" type="text" placeholder="Category">
                                        @foreach(trans('category') as $value => $label)
                                        <option @if(old('category') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="form-label fw-bold" for="sponser">Sponsor<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" name="sponser" value="{{old("sponser")}}"  placeholder="Sponsor" class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="working_as">Working As<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" name="working_as" value="{{old("working_as")}}"  placeholder="working As" class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="desigination">Visa Designation<a style="text-decoration: none;color:red">*</a></label>
                             <div class="form-label">
                                <select id="desigination" name="desigination"  class="form-control" type="text" placeholder="Designation">
                                    @foreach(trans('designation') as $value => $label)
                                    <option @if(old('designation') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="depart">Department<a style="text-decoration: none;color:red">*</a></label>
                             <div class="form-label">
                                <select id="depart" name="depart"  class="form-control" type="text" placeholder="Department">
                                    @foreach(trans('department') as $value => $label)
                                    <option @if(old('department') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="status">Status<a style="text-decoration: none;color:red">*</a></label>
                             <div class="form-label">
                                <select id="status" name="status"  class="form-control" type="text" placeholder="Department">
                                    @foreach(trans('status') as $value => $label)
                                    <option @if(old('status') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="religion">Religion<a style="text-decoration: none;color:red">*</a></label>
                                <div class="form-label">
                                    <select id="religion" name="religion"  class="form-control" type="text" placeholder="Religion">
                                        @foreach(trans('religion') as $value => $label)
                                        <option @if(old('religion') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                        @endforeach
                                    </select>
                                    </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="nationality">Nationality<a style="text-decoration: none;color:red">*</a></label>
                                <div class="form-label">
                                <select id="nationality" name="nationality"  class="form-control" type="text" placeholder="Religion">
                                    @foreach(trans('nationality') as $value => $label)
                                    <option @if(old('nationality') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="company">Company<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" class="form-control" value="{{old("company")}}"  placeholder="company" name="company">
                            </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="division">Division<a style="text-decoration: none;color:red">*</a></label>
                                <div class="form-label">
                                    <select id="division" name="division"  class="form-control" type="text" placeholder="Division">
                                        @foreach(trans('division') as $value => $label)
                                        <option @if(old('division') == $value) selected @endif value="{{ $value }}">{{ $label }}</option>
                                        @endforeach
                                    </select>
                                    </div>
                               </div>
                            <div class="form-group col-md-4">
                                <label class="form-label fw-bold" for="city">Current Location<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" class="form-control" value="{{old("city")}}"  placeholder="City" name="city">
                            </div>

                            <div class="form-group col-md-6">
                                <label class="form-label fw-bold" for="phone">Phone<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" class="form-control" value="{{old("phone")}}"  placeholder="Phone" name="phone" pattern="[0-9]{10}" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="form-label fw-bold" for="pay_group">Pay Group<a style="text-decoration: none;color:red">*</a></label>
                                <input type="text" class="form-control" value="{{old("pay_group")}}"  placeholder="PayGroup" name="pay_group">
                            </div>

                            <div class="form-group row ">
                                <div class="col-md-8">
                                    <button type="submit" class="btn btn-primary ">
                                        {{ __('Add') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

              </div>

            </div>
            </div>
        </div>
          </div>

{{--employee edit--}}

          @foreach ($employes as $employe)
     <div class="modal fade" id="edit_employee_{{$employe->id}}">
              <div class="modal-dialog modal-xl">
                <div class="modal-content">
                  <div class="modal-header bg-primary">
                    <h4 class="modal-title" align="center"><b>Edit Employee</b></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span></button>

                  </div>
                  <div class="modal-body">
                    <div class="card-body">
                        <form method="POST" class="form-row" action="{{ route('employeemaster.update',$employe->id) }}" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="form-group col-md-6">
                                <label for="employee_id" class="form-label fw-bold" readonly="readonly">Employee Id</label>
                                <div class="border border-secondary rounded p-2">
                                    {{"EMP00".$employe->id}}
                                </div>
                            </div>

                          {{-- <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="employee_no">Employee Number</label>
                            <input type="text" name="employee_no" value="{{old("employee_no",$employe->employee_no)}}"  placeholder="Employee Number" class="form-control">
                        </div> --}}
                        {{-- <div class="form-group mb-3">
                            <label for="fullname" class="form-label fw-bold">Employee Name</label>
                            <input type="text" name="fullname" value="{{old("fullname",$employe->fullname)}}" placeholder="Full Name" class="form-control">
                        </div> --}}
                        <div class="form-group col-md-6">
                            <label for="firstname" class="form-label fw-bold">First Name</label>
                            <input type="text" name="firstname" value="{{old("firstname",$employe->firstname)}}" placeholder="Employee FirstName" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="lastname" class="form-label fw-bold">Last Name</label>
                            <input type="text" name="lastname" value="{{old("lastname",$employe->lastname)}}" placeholder="Employee LastName" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="middlename" class="form-label fw-bold">Middle Name</label>
                            <input type="text" name="middlename" value="{{old("middlename",$employe->middlename)}}" placeholder="Employee MiddleName" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="hire_date">Date of Joining</label>
                            <input type="date" class="form-control" value="{{old("hire_date",$employe->hire_date)}}"  placeholder="Hiring Date" name="hire_date">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="category">Category</label>
                            <div class="form-label">
                                <select id="category" name="category"  class="form-control" type="text" placeholder="Category">
                                     @foreach(trans('category') as $value => $label)
                                     <option @if(($employe->category ?? old('category')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="sponser">Sponsor</label>
                            <input type="text" class="form-control" value="{{old("sponser",$employe->sponser)}}"  name="sponser" placeholder="Sponser">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="working_as">Working As</label>
                            <input type="text" class="form-control" value="{{old("working_as",$employe->working_as)}}"  name="working_as" placeholder="Working As">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="desigination">Visa Designation</label>
                            <div class="form-label">
                                <select id="desigination" name="desigination"  class="form-control" type="text" placeholder="Designation">
                                    @foreach(trans('designation') as $value => $label)
                                    <option @if(($employe->desigination ?? old('desigination')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>
                                    @endforeach
                                </select>
                                </div>
                        </div>


                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="depart">Department</label>
                            <div class="form-label">
                                <select id="depart" name="depart"  class="form-control" type="text" placeholder="Department">
                                    @foreach(trans('department') as $value => $label)
                                    <option @if(($employe->depart ?? old('department')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>
                                @endforeach
                                </select>

                                </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="status">Status</label>
                            <div class="form-label">
                                <select id="status" name="status"  class="form-control" type="text" placeholder="Department">
                                    @foreach(trans('status') as $value => $label)
                                    <option @if(($employe->status ?? old('status')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>

                                    @endforeach
                                </select>
                                </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="religion">Religion</label>
                            <div class="form-label">
                                <select id="religion" name="religion"  class="form-control" type="text" placeholder="Religion">
                                    @foreach(trans('religion') as $value => $label)
                                    <option @if(($employe->religion ?? old('religion')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>
                                    @endforeach
                                </select>
                                </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="depart">Nationality</label>
                            <div class="form-label">
                                <select id="nationality" name="nationality"  class="form-control" type="text" placeholder="Religion">
                                    @foreach(trans('nationality') as $value => $label)
                                    <option @if(($employe->nationality ?? old('nationality')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>
                                    @endforeach
                                </select>
                                </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="company">Company</label>
                            <input type="text" class="form-control" value="{{old("company",$employe->company)}}"  name="company" placeholder="Company">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="division">Division</label>
                            <div class="form-label">
                            <select id="division" name="division"  class="form-control" type="text" placeholder="Division">
                                @foreach(trans('division') as $value => $label)
                                <option @if(($employe->division ?? old('division')) == $value) selected @endif value="{{ $value }}">{{$label}}</option>
                                @endforeach
                            </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="form-label fw-bold" for="city">Current location</label>
                            <input type="text" class="form-control" value="{{old("city",$employe->city)}}"  placeholder="City" name="city">
                        </div>

                        <div class="form-group col-md-6">
                            <label class="form-label fw-bold" for="Phone">Phone</label>
                            <input type="PhoneNumber" class="form-control" value="{{old("phone",$employe->phone)}}"  placeholder="Phone" name="phone">
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label fw-bold" for="pay_group">Pay Group</label>
                            <input type="text" class="form-control" value="{{old("pay_group",$employe->pay_group)}}"  placeholder="Pay Group" name="pay_group">
                        </div>


                        <div class="form-group row ">
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-primary ">
                                    {{ __('Update') }}
                                </button>
                            </div>
                        </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
    @endforeach

{{--employee view--}}

@foreach ($employes as $employe)
    <div class="modal fade" id="view_employee_{{$employe->id}}">
             <div class="modal-dialog modal-xl">
               <div class="modal-content">
                 <div class="modal-header bg-primary">
                   <h4 class="modal-title"><b>View Employee</b></h4>
                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span></button>

                 </div>

                 <div class="modal-body">
                   <div class="card-body ">

                    <div class="row">
                    <div class="col-md-12">

                        <h3 class="text-primary font-weight-bold text-center">
                           Profile: {{$employe->firstname}}
                       </h3>

                        <div class="form-row">
                        {{-- <div class="form-group col-md-6">
                                    <label for="fullname" class="form-label fw-bold">Employee Number</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->employee_no}}
                                    </div>
                                </div> --}}
                                <div class="form-group col-md-6">
                                    <label for="employee_id" class="form-label fw-bold">Employee Id</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{"EMP00".$employe->id}}
                                    </div>
                                </div>
                                {{-- <div class="form-group mb-3">
                                    <label for="fullname" class="form-label fw-bold">Employee Name</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->fullname}}
                                    </div>
                                </div> --}}

                                <div class="form-group col-md-6">
                                    <label for="firstname" class="form-label fw-bold">First Name</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->firstname}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="lastname" class="form-label fw-bold">Last Name</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->lastname}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="middlename" class="form-label fw-bold">Middle Name</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->middlename}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="JoinDate" class="form-label fw-bold">Date of Joining</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->hire_date}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="catogory" class="form-label fw-bold">Category</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->category}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="sponsor" class="form-label fw-bold">Sponsor</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->sponser}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="working_as" class="form-label fw-bold">Working As</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->working_as}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="desigination" class="form-label fw-bold">Visa Designation</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->desigination}}
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="depart" class="form-label fw-bold">Department</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->depart}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="status" class="form-label fw-bold">Status</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->status}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="religion" class="form-label fw-bold">Religion</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->religion}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="nationality" class="form-label fw-bold">Nationality</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->nationality}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="company" class="form-label fw-bold">Company</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->company}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="division" class="form-label fw-bold">Division</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->division}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="city" class="form-label fw-bold">Current Location</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->city}}
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="phone" class="form-label fw-bold">Phone</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->phone}}
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="pay_group" class="form-label fw-bold">Pay Group</label>
                                    <div class="border border-secondary rounded p-2">
                                        {{$employe->pay_group}}
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    </div>

                   </div>
                </div>
              </div>
            </div>
    @endforeach

{{--employee index--}}

            <div class="card">

                <div class="card-body">
                    <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Employee Id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Department</th>
                                <th>Date of Joining</th>
                                <th>Show</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($employes as $key => $employe)
                                <tr>
                                    <td>{{$key+=1}}</td>
                                    <td>{{"EMP00".$employe->id}}</td>
                                    <td>{{$employe->firstname}}</td>
                                    <td>{{$employe->lastname}}</td>
                                    <td>{{$employe->depart}}</td>
                                    <td>{{$employe->hire_date}}</td>
                                    <td>
                                        <a href="{{route("employeemaster.show",$employe->id)}}"
                                            class="btn btn-primary btn-circle btn-sm"  data-toggle="modal" data-target="#view_employee_{{$employe->id}}" >
                                            <i class="fas fa-flag"></i>
                                        </a>

                                    </td>

                                       <td> <a href="{{route("employeemaster.edit",$employe->id)}}"
                                            class="btn btn-info btn-circle btn-sm mx-2" data-toggle="modal" data-target="#edit_employee_{{$employe->id}}" >
                                            <i class="fas fa-check"></i>
                                        </a></td>
                                       <td> <form id="{{$employe->id}}" action="{{route("employeemaster.destroy",$employe->id)}}" method="post">
                                            @csrf
                                            @method("DELETE")
                                        </form>
                                        <button onclick="deleteAd({{$employe->id}})"
                                            type="submit" class="btn btn-sm btn-danger">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                 </div>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')

@stop

@section('js')
{{--Datatable search bar and export button code here--}}

    <script>
         $("#myTable").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": [
        {
            extend: 'collection',
            text: '<i class="fa fa-file-export" aria-hidden="true"></i>',

            buttons: [ 'csv', 'excel', 'pdf','print' ]
        },

        [
            'colvis'
        ]
    ]
    }).buttons().container().appendTo('#myTable_wrapper .col-md-6:eq(0)');
    $('#myTable1').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });


 </script>

 {{--Delete Button Sweet Alert Code here--}}

    @if(session()->has("success"))
        <script>
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: "{{session()->get('success')}}",
                showConfirmButton: false,
                timer: 3500
            });
        </script>
    @endif
    <script>
        function deleteAd(id){
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger mr-2'
                },
                buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, cancel!',
                    reverseButtons: true
                }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(id).submit();
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your data was not deleted..',
                        'error'
                    )
                }
                })
        }
    </script>

{{--Date of joining validation code here--}}

    <script >
        var input = document.getElementById("hire_date");
        var today = new Date();
        var day = today.getDate();

        // Set month to string to add leading 0
        var mon = new String(today.getMonth()+1); //January is 0!
        var yr = today.getFullYear();

          if(mon.length < 2) { mon = "0" + mon; }

          var date = new String( yr + '-' + mon + '-' + day );

        input.disabled = false;
        input.setAttribute('max', date);
</script>

@stop
