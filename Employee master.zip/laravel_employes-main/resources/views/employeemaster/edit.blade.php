@extends('adminlte::page')

@section('title', 'Employes Management System | Update')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="container-fluid">
                <div class="col-md-6 mx-auto">
                    @include('layouts.alert')
                </div>
            </div>
            <div class="card my-5">
                <div class="card-header bg-white text-center p-3">
                    <h3 class="text-primary font-weight-bold">
                        Update employee
                    </h3>
                </div>
                <div class="card-body">
                    <form method="POST" class="mt-3" action="{{ route('employes.update',$employe->employee_no) }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        {{-- <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="employee_no">Employee Number</label>
                            <input type="text" name="employee_no" value="{{old("employee_no",$employe->employee_no)}}"  placeholder="Employee Number" class="form-control">
                        </div> --}}
                        {{-- <div class="form-group mb-3">
                            <label for="fullname" class="form-label fw-bold">Employee Name</label>
                            <input type="text" name="fullname" value="{{old("fullname",$employe->fullname)}}" placeholder="Full Name" class="form-control">
                        </div> --}}
                        <div class="form-group mb-3">
                            <label for="firstname" class="form-label fw-bold">Employee FirstName</label>
                            <input type="text" name="firstname" value="{{old("firstname",$employe->firstname)}}" placeholder="Employee FirstName" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="lastname" class="form-label fw-bold">Employee LastName</label>
                            <input type="text" name="lastname" value="{{old("lastname",$employe->lastname)}}" placeholder="Employee LastName" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="middlename" class="form-label fw-bold">Employee MiddleName</label>
                            <input type="text" name="middlename" value="{{old("middlename",$employe->middlename)}}" placeholder="Employee MiddleName" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="hire_date">Join Date</label>
                            <input type="date" class="form-control" value="{{old("hire_date",$employe->hire_date)}}"  placeholder="Hiring Date" name="hire_date">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="category">Employee Category</label>
                            <input type="text" class="form-control" value="{{old("category",$employe->category)}}"  name="category" placeholder="Employee Category">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="sponser">Sponser</label>
                            <input type="text" class="form-control" value="{{old("sponser",$employe->sponser)}}"  name="sponser" placeholder="Sponser">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="working_as">Working As</label>
                            <input type="text" class="form-control" value="{{old("working_as",$employe->working_as)}}"  name="working_as" placeholder="Working As">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="desigination">Visa Desigination</label>
                            <input type="text" class="form-control" value="{{old("desigination",$employe->desigination)}}"  name="desigination" placeholder="Visa Desigination">
                        </div>


                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="depart">Departement</label>
                            <input type="text" class="form-control" value="{{old("depart",$employe->depart)}}"  name="depart" placeholder="Departement">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="status">Status</label>
                            <input type="text" class="form-control" value="{{old("status",$employe->status)}}"  name="status" placeholder="Status">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="religion">Religion</label>
                            <input type="text" class="form-control" value="{{old("religion",$employe->religion)}}"  name="religion" placeholder="Religion">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="depart">Nationality</label>
                            <input type="text" class="form-control" value="{{old("nationality",$employe->nationality)}}"  name="nationality" placeholder="Nationality">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="company">Company</label>
                            <input type="text" class="form-control" value="{{old("company",$employe->company)}}"  name="company" placeholder="Company">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="division">Division</label>
                            <input type="text" class="form-control" value="{{old("division",$employe->division)}}"  name="division" placeholder="Division">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="city">Current location</label>
                            <input type="text" class="form-control" value="{{old("city",$employe->city)}}"  placeholder="City" name="city">
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="pay_group">Phone</label>
                            <input type="text" class="form-control" value="{{old("phone",$employe->phone)}}"  placeholder="Phone" name="phone">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="pay_group">Pay Group</label>
                            <input type="text" class="form-control" value="{{old("pay_group",$employe->pay_group)}}"  placeholder="Pay Group" name="pay_group">
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Update') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

