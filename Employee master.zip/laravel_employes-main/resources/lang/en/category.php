<?php

return [
    'Staff' => 'Staff',
    'Labour' => 'Labour',

];
