<?php

return [
    'Indian' => 'Indian',
    'Pakistan' => 'Pakistan',
    'Bangladesh' => 'Bangladesh',
    'United Arab Emirates' => 'United Arab Emirates',
    'African' => 'African',
    'Sri lanka' => 'Sri lanka',

];

