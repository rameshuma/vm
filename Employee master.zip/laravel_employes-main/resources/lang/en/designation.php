<?php

return [
    'Site Manager' => 'Site Manager',
    'CEO' => 'CEO',
    'Site Incharge' => 'Site Incharge',

];

