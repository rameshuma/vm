<?php

return [
    'Site Construction' => 'Site Construction',
    'Concrete' => 'Concrete',
    'Masonary' => 'Masonary',
    'Metals' => 'Metals',

];

