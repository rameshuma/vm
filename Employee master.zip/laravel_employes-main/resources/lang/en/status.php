<?php

return [
    'On leave' => 'On leave',
    'Vacation' => 'Vacation',
    'Long Leave' => 'Long Leave',
    'Resigned' => 'Resigned',
    'Terminaton' => 'Terminaton',

];
