<?php

return [
    'Christianity' => 'Christianity',
    'Islam' => 'Islam',
    'Hinduism' => 'Hinduism',
    'Buddhism' => 'Buddhism',
    'Folk relegions' => 'Folk relegions',
    'Sikhism' => 'Sikhism',
    'Other religions' => 'Other religions',

];

