<?php

return [
    'General Staff' => 'General Staff',
    'Electrical Department' => 'Electrical Department',
    'HVAC Department' => 'HVAC Department',
    'Plumbing Department' => 'Plumbing Department',
    'Maintenance Department' => 'Maintenance Department',
];
//select * from employee_masters_table where id=''
