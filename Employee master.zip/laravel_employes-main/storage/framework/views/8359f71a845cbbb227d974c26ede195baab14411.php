<?php $__env->startSection('title'); ?>
    Employes Management System
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5 p-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card p-3">
                <h2>Welcome To AL BORJ AL MUMTAZ TECH CONT. </h2>
                <hr>
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-info">Login</a>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <div class="d-flex justify-content-center align-items-center">
                        <div class="logout_link">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-0">
                                    <button type="submit" class="btn btn-outline-danger mx-3">
                                        <?php echo e(__('Logout')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="home_page_link">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-primary">Home</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_employes-main\resources\views/welcome.blade.php ENDPATH**/ ?>