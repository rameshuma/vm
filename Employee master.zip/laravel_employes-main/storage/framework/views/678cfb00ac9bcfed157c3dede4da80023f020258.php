<?php if($errors->any()): ?>
    <ul class="list-group">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item text-danger border border-danger rounded-0 mb-1">
                <?php echo e($error); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laravel_employes-main\resources\views/layouts/alert.blade.php ENDPATH**/ ?>