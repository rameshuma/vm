<?php $__env->startSection('title', 'Employes Management System | Update'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="container-fluid">
                <div class="col-md-6 mx-auto">
                    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="card my-5">
                <div class="card-header bg-white text-center p-3">
                    <h3 class="text-primary font-weight-bold">
                        Update employee
                    </h3>
                </div>
                <div class="card-body">
                    <form method="POST" class="mt-3" action="<?php echo e(route('employes.update',$employe->employee_no)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        
                        <div class="form-group mb-3">
                            <label for="firstname" class="form-label fw-bold">Employee FirstName</label>
                            <input type="text" name="firstname" value="<?php echo e(old("firstname",$employe->firstname)); ?>" placeholder="Employee FirstName" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="lastname" class="form-label fw-bold">Employee LastName</label>
                            <input type="text" name="lastname" value="<?php echo e(old("lastname",$employe->lastname)); ?>" placeholder="Employee LastName" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="middlename" class="form-label fw-bold">Employee MiddleName</label>
                            <input type="text" name="middlename" value="<?php echo e(old("middlename",$employe->middlename)); ?>" placeholder="Employee MiddleName" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="hire_date">Join Date</label>
                            <input type="date" class="form-control" value="<?php echo e(old("hire_date",$employe->hire_date)); ?>"  placeholder="Hiring Date" name="hire_date">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="category">Employee Category</label>
                            <input type="text" class="form-control" value="<?php echo e(old("category",$employe->category)); ?>"  name="category" placeholder="Employee Category">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="sponser">Sponser</label>
                            <input type="text" class="form-control" value="<?php echo e(old("sponser",$employe->sponser)); ?>"  name="sponser" placeholder="Sponser">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="working_as">Working As</label>
                            <input type="text" class="form-control" value="<?php echo e(old("working_as",$employe->working_as)); ?>"  name="working_as" placeholder="Working As">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="desigination">Visa Desigination</label>
                            <input type="text" class="form-control" value="<?php echo e(old("desigination",$employe->desigination)); ?>"  name="desigination" placeholder="Visa Desigination">
                        </div>


                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="depart">Departement</label>
                            <input type="text" class="form-control" value="<?php echo e(old("depart",$employe->depart)); ?>"  name="depart" placeholder="Departement">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="status">Status</label>
                            <input type="text" class="form-control" value="<?php echo e(old("status",$employe->status)); ?>"  name="status" placeholder="Status">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="religion">Religion</label>
                            <input type="text" class="form-control" value="<?php echo e(old("religion",$employe->religion)); ?>"  name="religion" placeholder="Religion">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="depart">Nationality</label>
                            <input type="text" class="form-control" value="<?php echo e(old("nationality",$employe->nationality)); ?>"  name="nationality" placeholder="Nationality">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="company">Company</label>
                            <input type="text" class="form-control" value="<?php echo e(old("company",$employe->company)); ?>"  name="company" placeholder="Company">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="division">Division</label>
                            <input type="text" class="form-control" value="<?php echo e(old("division",$employe->division)); ?>"  name="division" placeholder="Division">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="city">Current location</label>
                            <input type="text" class="form-control" value="<?php echo e(old("city",$employe->city)); ?>"  placeholder="City" name="city">
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="pay_group">Phone</label>
                            <input type="text" class="form-control" value="<?php echo e(old("phone",$employe->phone)); ?>"  placeholder="Phone" name="phone">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="pay_group">Pay Group</label>
                            <input type="text" class="form-control" value="<?php echo e(old("pay_group",$employe->pay_group)); ?>"  placeholder="Pay Group" name="pay_group">
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Update')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_employes-main\resources\views/employes/edit.blade.php ENDPATH**/ ?>