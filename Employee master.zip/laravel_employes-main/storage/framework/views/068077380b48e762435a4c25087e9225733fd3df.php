<?php $__env->startSection('title', 'Employes Management System | '.$employe->fullname); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h3 class="text-primary font-weight-bold text-center">
               Profile: <?php echo e($employe->firstname); ?>

           </h3>
           <div class="col-sm-4">
            <a class="btn btn-primary" onclick="history.back()">Back</a>
          </div>
            <div class="card my-5">


                
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Employee Number</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->employee_no); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Employee Id</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e("EMP-00".$employe->id); ?>

                        </div>
                    </div>
                    

                    <div class="form-group mb-3">
                        <label for="firstname" class="form-label fw-bold">First Name</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->firstname); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="lastname" class="form-label fw-bold">Last Name</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->lastname); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="middlename" class="form-label fw-bold">Middle Name</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->middlename); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="JoinDate" class="form-label fw-bold">Join Date</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->hire_date); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="catogory" class="form-label fw-bold">Employee Category</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->catogory); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Sponser</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->sponser); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Working As</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->working_as); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Visa Desigination</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->desigination); ?>

                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Departement</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->depart); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Status</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->status); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Nationality</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->nationality); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Company</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->company); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Division</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->division); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Current Location</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->city); ?>

                        </div>
                    </div>


                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Phone</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->phone); ?>

                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fullname" class="form-label fw-bold">Pay Group</label>
                        <div class="border border-secondary rounded p-2">
                            <?php echo e($employe->pay_group); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_employes-main\resources\views/employes/show.blade.php ENDPATH**/ ?>