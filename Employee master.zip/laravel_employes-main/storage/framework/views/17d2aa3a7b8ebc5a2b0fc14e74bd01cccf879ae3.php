<?php $__env->startSection('title', 'Employes Management System | Create'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="container-fluid">
                <div class="col-md-6 mx-auto">
                    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <h3 class="text-primary font-weight-bold text-center">
                Add New Employee
            </h3>
            <div class="col-sm-4">
                <a class="btn btn-primary" onclick="history.back()">Back</a>
              </div>
            <div class="card my-8">

                <div class="card-body">
                    <form method="POST" class="mt-3" action="<?php echo e(route('employes.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label for="employee_no" class="form-label fw-bold">Employee Number</label>
                            <input type="number" name="employee_no" value="<?php echo e(old("employee_no")); ?>" placeholder="Employee Number" class="form-control">
                        </div>
                        
                        <div class="form-group mb-3">
                            <label for="fullname" class="form-label fw-bold">Employee First Name*</label>
                            <input type="text" name="firstname" value="<?php echo e(old("firstname")); ?>" placeholder="First Name" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="fullname" class="form-label fw-bold">Employee Last Name*</label>
                            <input type="text" name="lastname" value="<?php echo e(old("lastname")); ?>" placeholder="Last Name" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="fullname" class="form-label fw-bold">Employee Middle Name</label>
                            <input type="text" name="middlename" value="<?php echo e(old("middlename")); ?>" placeholder="Middle Name" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="hire_date">Join Date*</label>
                            <input type="date" class="form-control" value="<?php echo e(old("hire_date")); ?>"  placeholder="Hiring Date" name="hire_date">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold">Employee category</label>
                            <div class="form-label">
                                <select class="form-control" name="category" value="<?php echo e(old("catogory")); ?>" type="text" placeholder="Catogory">
                                    <option>Temporary</option>
                                    <option>Permanent</option>

                                </select>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="sponser">Sponser*</label>
                            <input type="text" name="sponser" value="<?php echo e(old("sponser")); ?>"  placeholder="Sponser" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="working_as">Working As*</label>
                            <input type="text" name="working_as" value="<?php echo e(old("working_as")); ?>"  placeholder="working_as" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="desigination">Visa Desigination*</label>
                         <div class="form-label">
                                <select class="form-control" name="desigination" value="<?php echo e(old("desigination")); ?>" type="text" placeholder="Desigination">
                                    <option >Seo Analyst</option>
                                    <option >CEO</option>

                                </select>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="depart">Departement*</label>
                         <div class="form-label">
                                <select class="form-control" name="depart" value="<?php echo e(old("depart")); ?>" type="text" placeholder="Departement">
                                    <option >Management</option>
                                    <option >Marketing</option>
                                    <option >Operations</option>
                                    <option >Finance</option>
                                    <option >Human Resourse</option>
                                    <option >Purchase</option>

                                </select>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="status">Status*</label>
                         <div class="form-label">
                                <select class="form-control" name="status" value="<?php echo e(old("status")); ?>" type="text" placeholder="Status">
                                    <option>Active</option>
                                    <option>Deactive</option>

                                </select>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="religion">Religion*</label>
                            <input type="text" name="religion" value="<?php echo e(old("religion")); ?>"  placeholder="religion" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="nationality">Nationality*</label>
                            <input type="text" name="nationality" value="<?php echo e(old("nationality")); ?>"  placeholder="Nationality" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="company">Company*</label>
                            <input type="text" class="form-control" value="<?php echo e(old("company")); ?>"  placeholder="company" name="company">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="division">Division*</label>
                         <div class="form-label">
                                <select class="form-control" name="division" value="<?php echo e(old("division")); ?>" type="text" placeholder="division">
                                    <option>Active</option>
                                    <option>Deactive</option>

                                </select>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="city">Current Location*</label>
                            <input type="text" class="form-control" value="<?php echo e(old("city")); ?>"  placeholder="City" name="city">
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="phone">Phone*</label>
                            <input type="text" class="form-control" value="<?php echo e(old("phone")); ?>"  placeholder="Phone" name="phone">
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label fw-bold" for="pay_group">Pay Group*</label>
                            <input type="text" class="form-control" value="<?php echo e(old("pay_group")); ?>"  placeholder="PayGroup" name="pay_group">
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Create')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_employes-main\resources\views/employes/create.blade.php ENDPATH**/ ?>