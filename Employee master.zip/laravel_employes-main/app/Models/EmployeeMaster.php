<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeMaster extends Model
{
    use HasFactory;
    protected $fillable =
    [
         "employee_no","fullname","firstname","lastname","middlename",
        "hire_date","category","sponser","working_as","desigination","depart",
        "status","religion","nationality","company","division","city","phone","pay_group"
    ];
}
