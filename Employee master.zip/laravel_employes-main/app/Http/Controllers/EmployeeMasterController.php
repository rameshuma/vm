<?php

namespace App\Http\Controllers;
use App\Models\EmployeeMaster;

use Illuminate\Http\Request;

class EmployeeMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employes = EmployeeMaster::all();
        return view('employeemaster.index')->with([
            'employes' => $employes
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employeemaster.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'id'=> '|unique:employes',
            'employee_no' => '',

            'firstname' => 'required',
            'lastname' => 'required',
            'middlename' => '',
            'hire_date' => 'required',
            'category' => 'required',
            'sponser' => 'required',
            'working_as' => 'required',
            'desigination' => 'required',
            'depart' => 'required',
            'status' => 'required',
            'religion' => 'required',
            'nationality' => 'required',
            'company' => 'required',
            'division' => 'required',
            'city' => 'required',
            'phone' => 'required|numeric',
            'pay_group' => 'required'
        ]);
        $data = $request->except(['_token']);
        EmployeeMaster::create($data);
        return redirect()->route("employeemaster.index")->with([
            "success" => "Employee added successfully"
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $employe = EmployeeMaster::where('id', $id)->first();
        return view("employeemaster.show")->with([
            "employes" => $employe
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employe = EmployeeMaster::where('id', $id)->first();
        return view("employeemaster.edit")->with([
            "employes" => $employe

        ]);
     }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employe = EmployeeMaster::where('id', $id)->first();
        $this->validate($request, [
            'id'=> '|unique:employes,id,' . $employe->id,
            'employee_no' => '',

            'firstname' => 'required',
            'lastname' => 'required',
            'middlename' => '',
            'hire_date' => 'required',
            'category' => 'required',
            'sponser' => 'required',
            'working_as' => 'required',
            'desigination' => 'required',
            'depart' => 'required',
            'status' => 'required',
            'religion' => 'required',
            'nationality' => 'required',
            'company' => 'required',
            'division' => 'required',
            'city' => 'required',
            'phone' => 'required|numeric',
            'pay_group' => 'required'
        ]);
        $selectedValue = $request->input('category');
        $data = $request->except(['_token', '_method']);
        $employe->update($data);

        return redirect()->route("employeemaster.index")->with([
            "success" => "Employee updated successfully"
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employe = EmployeeMaster::where('id', $id)->first();
        $employe->delete();
        return redirect()->route("employeemaster.index")->with([
            "success" => "Employee deleted successfully"
        ]);
    }
}
